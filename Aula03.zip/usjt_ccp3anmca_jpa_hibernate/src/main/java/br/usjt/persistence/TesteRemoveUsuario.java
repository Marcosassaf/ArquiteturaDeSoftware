package br.usjt.persistence;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;

import br.usjt.model.Usuario;
import br.usjt.util.JPAUtil;

public class TesteRemoveUsuario {
	public static void main(String[] args) {
		EntityManager manager = JPAUtil.getEntityManager();
		EntityTransaction transaction = manager.getTransaction();
		transaction.begin();
		Usuario u = manager.find(Usuario.class, 1L);
		manager.remove(u); //Removendo nosso usuario
		transaction.commit();
		manager.close();
		JPAUtil.close();
	}
}