package br.usjt.ExercicioAula02;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExercicioAula02Application {

	public static void main(String[] args) {
		SpringApplication.run(ExercicioAula02Application.class, args);
	}

}
